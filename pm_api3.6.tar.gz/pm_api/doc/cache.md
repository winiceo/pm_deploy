## 大屏相关缓存定义
#bpwalls
类型    hset
        bpwall_id=>jsonString

#存储管理员记数信息
#例：admin:wFXTRrxGWH:og54Btzs5Iwp403MVgjCbiDUzru0
类型   hset
      key:`admin:${bpwall_id}:${openid}`
          {
            admin_ds_times:10,
            admin_el_times:10,
            admin_bp_times:10,
           }

存储所有管理员
    key:${bpwall_id}:${openid}
    value:{
                                                 admin_ds_times:10,
                                                 admin_el_times:10,
                                                 admin_bp_times:10,
    }
#admins
    hset
