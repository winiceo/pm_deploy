'use strict';

// npm run dev DO NOT read this file
const env = require('./config/environment');

require('egg').startCluster({
  baseDir: __dirname,
  port: env.get('admin_port') || 7001, // default to 7001,
  workers: 1, // process.env.NODE_ENV === 'development' ? 1 : os.cpus().length

});
