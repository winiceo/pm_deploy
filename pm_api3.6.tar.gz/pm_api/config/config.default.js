'use strict';
const fs = require('fs');
const path = require('path');
const deepmerge = require('deepmerge');
module.exports = appInfo => {


  const root = [
    path.join(appInfo.baseDir, 'app/view'),
        // path.join(appInfo.baseDir, 'app/view2'),
  ];
  const config = {
    keys: '71an',
    development: {
      watchDirs: [ 'app', 'config', 'conf', 'index.js' ],
    },
    siteFile: {
      '/favicon.ico': fs.readFileSync(path.join(appInfo.baseDir, 'dist/favicon.ico')),
    },
    static: {
      prefix: '/',
      dir: path.join(appInfo.baseDir, 'dist/'),
    },
    security: {
      csrf: {
        enable: false,
      },
    },
    view: {
      root: root.join(', '),
      ext: 'html',
      cache: true,
      defaultExt: '.html',
      mapping: {
        '.ejs': 'ejs',
        '.nj': 'nunjucks',
        '.html': 'nunjucks',
      },
    },
    logrotator: {
      filesRotateBySize: [], // 需要按大小切割的文件，其他日志文件仍按照通常方式切割
      maxFileSize: 1 * 1024 * 1024, // 限制单个日志最大文件为1M，这是因为UAE上面显示最多只能是1M大小的数据
      maxFiles: 10, // 按大小切割时，文件最大切割的分数
      maxDays: 31, // 默认保存一个月的数据
      rotateDuration: 60000, // 按大小切割时，文件扫描的间隔时间
    },
    bodyParser: {
      formLimit: '1024kb',
      jsonLimit: '1024kb',
    },
    jwt: {
      secret: 'cool-jobs',
      option: {
        expiresIn: '1d',
      },
    },
    logger: {
      dir: path.join(appInfo.baseDir, '../logs/'),
    },
    notfound: {
      pageUrl: '/404',
    },
    onerror: {
            // 线上环境打开
             errorPageUrl: '/500',
    },
    middleware: [ 'errorHandler' ],
    errorHandler: {
            // 非 `/api/` 路径不在这里做错误处理，留给默认的 onerror 插件统一处理
      match: '/api',
    },
  };


  return deepmerge(config, require('./app.config.js'));


}
;
