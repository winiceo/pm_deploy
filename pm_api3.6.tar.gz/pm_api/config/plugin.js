exports.static = true;
exports.logrotator = true;
exports.i18n = true;
exports.development = true;

exports.session = true;
exports.userservice = true;
exports.userrole = false;
// exports.cors = {
//   domainWhiteList: [ 'http://localhost:8080',"http://hd.71an.com/" ],
//   allowMethods: 'GET,HEAD,PUT,POST,DELETE,PATCH',
//   enable: true,
//   package: 'egg-cors',
// };

exports.nunjucks = {
  enable: true,
  package: 'egg-view-nunjucks',
};
// exports.view = {
//   mapping: {
//
//     '.html': 'nunjucks',
//   },
// };
// exports.view = {
//   viewEngine: 'nunjucks',
//   mapping: {
//     '.html': 'nunjucks',
//   },
// };


// exports.view = {
//   enable: true,
//   cache: false,
//   package: 'egg-view-nunjucks',
// };

exports.jwt = {
  enable: true,
  package: 'egg-jwt',
};
exports.redis = {
  enable: true,
  package: '../egg-redis',
};

