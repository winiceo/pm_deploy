'use strict';

module.exports = function(app) {
  app.get('/', 'home.index');
};
