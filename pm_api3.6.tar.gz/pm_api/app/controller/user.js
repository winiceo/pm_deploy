'use strict';
const Parse = require('../lib/parse');
const moment = require('moment');
const _ = require('lodash');
const fs = require('hexo-fs');
const RedPackage = Parse.Object.extend('RedPackage');
module.exports = app => {
    class RedpackController extends app.Controller {

        constructor(ctx) {
            super(ctx);
            this.app = ctx.app;
            this.__ = this.ctx.__.bind(this.ctx);


        }


        * myredpack() {
            const {ctx, service} = this;
            const options = yield {
                userInfo: ctx.service.user.info(ctx.session.user_id),
                moneyTotal: app.redis.hget('money', ctx.session.user_id),
                //moneys: ctx.service.money.getList(ctx.session.user_id)
            };

            const userQuery = new Parse.Query('wechat_user');
            userQuery.equalTo('objectId', ctx.session.user_id);
            yield userQuery.first().then(function (user) {
                if (user) {
                    options.moneyTotal = user.get('money');
                }
            });

            console.log(options.moneyTotal);


            yield ctx.render('wechat/myredpack.html', options);

        }

        * moneyList() {
            const {ctx, service} = this;
            const page=ctx.query.num||1
            const ret = {
                code: 1,
                data: [],
            };

            const moneys = yield ctx.service.money.getList(ctx.session.user_id,page-1);
            // console.log(moneys);
            _.each(moneys, function (n) {
                const data = {
                    primary_money: n.get('money')/100,
                    type:n.get('title'),
                    create_time:ctx.helper.dateAt(n.createdAt),
                    bar_name: n.get('bar_name')||"",
                    style: 'color:rgb(255,136,71)',
                };
                ret.data.push(data);
            });
            if(moneys.length==0){
                ret.code=0
            }
            ctx.body = ret;
        }

        * withdraw() {
            const {ctx, service} = this;
            const options = {};
            const userQuery = new Parse.Query('wechat_user');
            userQuery.equalTo('objectId', ctx.session.user_id);
            yield userQuery.first().then(function (user) {
                if (user) {
                    options.user = user;
                }
            });


            yield ctx.render('wechat/withdraw.html', options);
        }

        * withdrawsave() {
            const {ctx, service} = this;
            const body = ctx.request.body;
            const money = (body.amount) ;
            const that=this;
            const ret = {
                error: 0,
                amount: money,
                message: '提现成功',
            };

            const bill = {
                type:3,
                money: body.amount,
                user_id:ctx.session.user_id
            }

            let result=yield service.money.createBill(bill)
            if(!result){
                ret.message = '提现失败';
                ret.amount = 0;
            }else{
                ret.amount = money;
            }


            ctx.body = ret;
        }


        /**
         * 管理员禁言用户消息
         */
        * black() {

            const {ctx, service} = this;
            const body = ctx.request.body;
            const id = ctx.params.id;
            const uid = body.uid;
            const time = parseInt(body.time);

            const adminInfo = yield service.admin.adminInfo(id, ctx.session.user_id);
            if (adminInfo) {
                let ret;
                if (time > 0) {
                    ret = yield app.redis.setex(`black:${id}:${uid}`, time, 1);
                } else if (time == 0) {
                    console.log('del');
                    ret = yield app.redis.del(`black:${id}:${uid}`);

                } else if (time == -1) {
                    ret = yield service.message.removeByUid(id, uid);
                }

                return ctx.body = {code: 1, data: '操作成功'};
            }
            return ctx.body = {code: 1, data: '无权操作'};

        }


    }
    return RedpackController;
};
