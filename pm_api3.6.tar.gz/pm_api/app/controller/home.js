'use strict';

exports.list = function* () {
  this.body = '来了';
};
exports.notFound = function* () {
  this.status = 404;
  yield this.render('404.html');
};

exports.error = function* () {
  yield this.render('500.html');
};

exports.redirect = function* () {

  this.redirect('http://71an.com');

};

exports.test = function* () {

  this.asdfas();

};

