/**
 * Created by leven on 17/2/23.
 */
'use strict';

exports.schedule = {
  interval: 3000,
  type: 'all',
  disable: true,
};

exports.task = function* (ctx) {
   // ctx.logger.info('all&&interval');
};
