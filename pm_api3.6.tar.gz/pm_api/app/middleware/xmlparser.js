/**
 * Created by leven on 17/2/20.
 */


const xmlParser = require('../lib/xml-parser');

module.exports = (options, app) => {


  return xmlParser(options);


};

