'use strict';

module.exports = app => {

    const checkid = app.middlewares.checkid({}, app);
    const checksession = app.middlewares.checksession({}, app);
    const xml = app.middlewares.xmlparser({}, app);
    const wechatPayment = app.middlewares.wechatpay({}, app);

    app.get('home', '/', 'home.list');
    // app.redirect('/test', '/home');
    // oss相关 后端会代理到此/api/p/开头的全部转发到此
    app.all('file', '/api/p/oss/list', 'oss.list');
    app.all('sign', '/api/p/oss/sign', 'oss.sign');

    // 大屏地址
    app.get('/screen/:id', checkid, 'screen.index');
    app.get('/wall/:id', 'screen.wall');
    app.all('/api/heart/:id', checkid, 'screen.heart');

    // 关闭大屏
    app.post('/api/bpwall/colse/:id', checkid, 'screen.close');

    // 大屏获取消息
    app.get('/api/bpmsg/:id', checkid, 'api.bpmsg');
    app.get('/api/newmsg/:id', checkid, 'api.newmsg');
    app.all('/api/bpover/:id', checkid, 'api.overbp');


    // 微信登录相关
    app.get('/app/:id', checkid, 'wechat.index');
    app.get('/callback/:id', checkid, 'wechat.callback');


    // 客户端获取消息
    app.all('/api/getmsg/:id', checkid, checksession, 'api.getmsg');
    app.all('/api/getmsg/history/:id', checkid, checksession, 'api.getmsg');

    app.all('/api/sendmsg/:type/:id', checkid, checksession, 'order.sendmsg');

    // 重新霸屏
    app.all('/api/rebp/:id', checkid, checksession, 'api.replaypb');
    // 禁言
    app.all('/api/blackuser/:id', checkid, checksession, 'user.black');


    app.all('/wall/redpack/status/:id', checkid, checksession, 'redpack.status');
    app.all('/wall/redpack/luck/:id', checksession, 'redpack.luck');
    app.all('/wall/redpack/rob/:id', checksession, 'redpack.rob');

    app.all('/order/pay/', checksession, 'order.pay');
    app.all('/api/pay/success/:id', checkid, checksession, 'order.success');


    app.all('/api/pay/notify', xml, wechatPayment.middleware(), 'order.notify');


    // 获取打赏对像及礼品
    app.all('/api/reward/:id', checkid, checksession, 'wall.getgp');


    // 其它
    // 表白页面
    app.get('/wechat/love/:id', checkid, checksession, 'love.index');
    app.all('/api/love/moreusers/:id', checkid, checksession, 'love.users');

    app.get('/wechat/face/:id', checkid, checksession, 'face.index');
    app.all('/api/face/moreuser/:id', checkid, checksession, 'face.moreuser');

    app.get('/wechat/talk/:id', checkid, checksession, 'talk.index');
    app.all('/api/talk/sendmsg/:id', checksession, 'talk.sendmsg');
    app.all('/api/talk/getmsg/:id', checksession, 'talk.getmsg');
    app.all('/api/talk/unread/:id', checksession, 'talk.unread');
    app.all('/api/talk/clearmsg/:id', checksession, 'talk.clearmsg');

    app.get('/wechat/richrank/:id', checkid, checksession, 'richrank.index');


    // 管理员删消息
    app.all('/api/delmsg/:id', checksession, 'message.remove');


    // 处理微信主动通知的消息
    const wechat = app.middlewares.wechat();

    app.all('wechat_message', '/api/wechat', wechat);


    // 红包相关

    // app.all('/api/redpack/create', "redpack.create");
    // app.all('/api/redpack/ready/:id', "redpack.read");
    // app.get('/api/redpack/rush/:id',checksession, 'redpack.getRush');
    // app.post('/api/redpack/rush/:id',checksession, 'redpack.postRush');

    app.get('/wechat/myredpack', checksession, 'user.myredpack');
    // 用户提现
    app.get('/wechat/money/withdraw', checksession, 'user.withdraw');

    app.post('/api/user/withdraw', checksession, 'user.withdrawsave');

    app.get('/api/user/money', checksession, 'user.moneyList');


    app.get('/wechat/paidui', checksession, 'user.myredpack');
    app.get('/wechat/paidui', checksession, 'user.myredpack');


    // 测试
// ////////////////////
    app.all('test.bp', '/test/ok1', 'test.ok1');
    app.all('test.bp', '/test/redis', 'test.redis');
    app.all('test.bp', '/test/:type', 'test.text');
    app.all('test.register', '/client/register', 'test.register');
    app.get('/test/wechat/:id', 'test.wechat');
    app.get('/test/menu', 'test.menu');
    app.get('/test/ok', 'test.ok');

    // app.get('/test/set', 'test1.set');
    // app.get('/test/get', 'test1.get');


    app.all('/test/notify', xml, 'order.notify');
    app.get('/api/test', app.controller.home.test);
    app.get('/test', app.controller.home.test);

    app.get('/rp/create', 'test.rp_create');

    // ////////////////////


    app.get('/500', app.controller.home.error);
    app.get('/*', app.controller.home.notFound);


};
