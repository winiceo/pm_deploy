/**
 * Created by leven on 17/2/26.
 */
'use strict';
module.exports = app => {

  app.beforeStart(function* () {

        // /console.log(app.redis)
        // 应用会等待这个函数执行完成才启动
        // app.redis.Command.setArgumentTransformer('hmset', function (args) {
        //     if (args.length === 2) {
        //         if (typeof Map !== 'undefined' && args[1] instanceof Map) {
        //             // utils is a internal module of ioredis
        //             return [args[0]].concat(utils.convertMapToArray(args[1]));
        //         }
        //         if ( typeof args[1] === 'object' && args[1] !== null) {
        //             args[1]=_.mapValues(args[1], function(n) {
        //                 return JSON.stringify(n);
        //             });
        //
        //             return [args[0]].concat(utils.convertObjectToArray(args[1]));
        //         }
        //     }
        //     return args;
        // });
        //
        // app.redis.Command.setReplyTransformer('hgetall', function (result) {
        //     console.log(typeof result)
        //     // result.forEach((key,n)=>{
        //     //     "use strict";
        //     //
        //     //     console.log(key,n)
        //     // })
        //     if (Array.isArray(result)) {
        //         var obj = {};
        //         for (var i = 0; i < result.length; i += 2) {
        //             obj[result[i]] = isJSON(result[i + 1])?JSON.parse(result[i + 1]):result[i + 1];
        //         }
        //         return obj;
        //     }
        //     return result;
        // });
        //
        // app.redis.Command.setReplyTransformer('hget', function (result) {
        //     console.log(typeof result)
        //
        //     result= isJSON(result)?JSON.parse(result):result;
        //
        //     return result;
        // });

        // app.redis.hmset('key', data)
        // app.redis.hgetall("key",function (err,result) {
        //     console.log(result)
        // })
        // app.redis.hget("key",'b',function (err,result) {
        //     console.log(result.ok)
        // })
        // console.log(yield app.redis.get('bpwall:love:wFXTRrxGWH'))
        // app.cities = yield app.curl('http://example.com/city.json', {
        //     method: 'GET',
        //     dataType: 'json',
        // });
        // app.event.on('say hello', function(data){
        //     console.log('Hello ' + data.name);
        // });

        // console.log(33333)
        // console.log(app.service)
        //
        //
        // app.event.on('redpack:*', (data, channel) => {
        //     console.log(data, channel)
        //      app.service.redpack.process(channel,data)
        // });

  });

};
