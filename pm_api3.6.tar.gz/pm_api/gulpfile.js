/**
 * Created by leven on 17/3/3.
 */
const eslint = require('gulp-eslint');
const gulp = require('gulp');
const eslintIfFixed = require('gulp-eslint-if-fixed');
const plugins = require('gulp-load-plugins')();
gulp.task('lint-fix', function () {
    return gulp.src('app/**/*.js')
        .pipe(eslint({
                "extends": ["eslint-config-egg","egg"],
                "parserOptions": {
                    "ecmaVersion": 2017
                },
                "rules": {
                    "strict": "off"
                }
            }
        ))
        .pipe(eslint({fix: true}))
        .pipe(eslint.format())
        .pipe(eslintIfFixed('app'));
});
// gulp.watch('source/javascript/**/*.js', ['jshint']);

gulp.task('file:watch', function () {
    // // Compile LESS files
    // gulp.watch('app/styles/**/*.less', ['less']);
    //
    // gulp.watch([
    //     'app/**/*.html',
    //     'app/scripts/**/*.js',
    //     'app/locales/**/*.json',
    // ]).on('change', plugins.browserSync.reload);

    gulp.watch(['./app/**/*.js','./config/*.js','./app.js'], function () {
        gulp.run('lint-fix');
    });
});

gulp.task('default', ['file:watch'])
