
const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
  autoescape: true,
  noCache:true,
  watch:true, });

const moment=require("moment")
const cache=require("../../lib/cache")

module.exports = function(config, req, res) {
  let body=req.body
  let ret={"error":0,"message":"删除管理员成功"}



  var adminQuery = new Parse.Query("admin");

  adminQuery.equalTo("objectId", body.id);



  adminQuery.first().then(function (admin) {

    var Bpwall = Parse.Object.extend({className: "bpwall"});

    var bpwall = new Bpwall();
    bpwall.id = req.session.bpwall_id
    let relation = bpwall.relation("admin")
    bpwall.fetch().then(function (wall) {

      cache.exec({bpwall_id:req.session.bpwall_id,name:'cache_admin'})

      relation.remove(admin)
      bpwall.save()
    })

    return admin.destroy()

  }).then(function(){
    res.json(ret)

  },function(error){
    ret.error=1;
    ret.message=error
    res.json(ret)

  })
};

