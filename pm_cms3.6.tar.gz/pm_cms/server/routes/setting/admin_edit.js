const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});

const moment = require("moment")

module.exports = function (config, req, res) {

    const ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    // let account_uid = req.session.account_uid
    let id = req.params.id
    let options = {}
    let query = new Parse.Query("admin");
    query.equalTo("objectId", id);
    query.first().then(function (admin) {
        if(!admin){
            admin = Parse.Object.extend("admin").createWithoutData()

        }
        options.admin = admin
        options.bpwall_id = id

        var promise = new Parse.Promise();
        ret.options=options

        config.view.render('setting/admin_edit.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            }

            ret.content = html
            promise.resolve(html + "");
        })
        return promise;

    }).then(function (html) {

        res.json(ret);

    }, function (err) {

        let ret = {
            err: err
        }
        res.json(ret)
    })

};

