let config = require("../config");
const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "操作成功"}
    //let account_uid= req.session.account_uid
    let options = {
        action: "edit"
    }

    //res.json(body)
    var query = new Parse.Query("admin");
    query.equalTo("objectId", body.id);

    let Admin = Parse.Object.extend("admin");
    let admin = new Admin();
    if (body.id) {

        admin.id = body.id
    } else {
        options.action = "add"
        delete(body.id)
    }
    console.log(body)
    admin.set(body)

    if (body.uid) {

        let WechatUser = Parse.Object.extend("wechat_user");

        wuser = new WechatUser();
        wuser.id = body.uid


        admin.set('wechatuser', wuser)
    }

    admin.save().then(function (gg) {
        cache.exec({bpwall_id:req.session.bpwall_id,name:'cache_admin'})

        console.log(gg.toJSON())
        "use strict";


        let promise = Parse.Promise.as();
        if (options.action == "add") {

            var Bpwall = Parse.Object.extend({className: "bpwall"});

            var bpwall = new Bpwall();
            bpwall.id = req.session.bpwall_id

            promise = bpwall.fetch().then(function (wall) {

                let relation = bpwall.relation("admin")
                relation.add(admin)
                bpwall.save()
            })
        }
        return promise

    }).then(function () {
        "use strict";
        let promise = Parse.Promise.as();
        if (!body.name) {
            promise = wuser.fetch().then(function (wuser) {
                "use strict";
                admin.set("name", wuser.get("nickname"))
                admin.save()
            })

        }
        return promise
    }).then(function () {

        res.json(ret)

    }, function (err) {
        "use strict";

        console.log(err)
        ret.error = 1;
        ret.message = err
        res.json(ret)
    })


};