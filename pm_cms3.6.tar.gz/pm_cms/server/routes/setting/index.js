module.exports = {
    init: function (app, middleware, config) {

        app.all('/administrator',
            require("./admin").bind(app, config));



        //添加管理员
        app.post("/administrator/save",
            middleware.clearRedirects,
            middleware.setUserIfTokenExists,
            require("./admin_save").bind(app, config));


        //添加管理员
        app.all('/administrator/add',require("./admin_edit").bind(app, config));

        app.all('/administrator/edit/:id',require("./admin_edit").bind(app, config));

        //删除管理员
        app.all('/administrator/delete',
            require("./admin_del").bind(app, config));


    }
};
