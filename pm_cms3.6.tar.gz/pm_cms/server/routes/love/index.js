module.exports = {
  init: function(app, middleware, config) {


    app.all('/wall/express_love',require("./setting").bind(app, config));

    app.all('/wall/express_love/setting',require("./setting").bind(app, config));
    app.all('/wall/love/item/edit/:id',require("./item_edit").bind(app, config));
    app.all('/wall/love/item/add',require("./item_edit").bind(app, config));
    app.all('/wall/love/item/save',require("./item_save").bind(app, config));
    app.all('/wall/love/item/remove',require("./item_remove").bind(app, config));



    app.all('/wall/express_love/themes', require("./love").bind(app, config) );

    app.all('/wall/love/edit/:id',require("./love_edit").bind(app, config));
    app.all('/wall/love/add',require("./love_edit").bind(app, config));
    app.all('/wall/love/save',require("./love_save").bind(app, config));
    app.all('/wall/love/remove',require("./love_remove").bind(app, config));

    app.all('/wall/express_love/base',  require("./love_base").bind(app, config));
    app.all('/wall/express_love/base/modifySettings',  require("./love_base_save").bind(app, config));



    app.all('/wall/express_love/records', function(req,res){
      res.sendfile("./server/routes/api/express_love_records.json")


    });

    app.all('/wall/express_love/base', function(req,res){
      res.sendfile("./server/routes/api/express_love_base.json")


    });

    app.all('/wall/express_love/editItem/id/:id', function(req,res){
      res.sendfile("./server/routes/api/express_love_edit_item.json")


    });


  }
};
