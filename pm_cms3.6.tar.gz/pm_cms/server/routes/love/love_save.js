let config = require("../config");
const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "保存成功"}
    //let account_uid= req.session.account_uid
    let options = {
        action: "edit"
    }

    //res.json(body)
    var query = new Parse.Query("love");
    query.equalTo("objectId", body.id);

    let Love = Parse.Object.extend("love");
    let love = new Love();
    if (body.id) {

        love.id = body.id
    }else{
        options.action="add"
        delete(body.id)
    }
    body.sort=parseInt(body.sort)
    body.duration=parseFloat(body.duration)
    body.fee=parseFloat(body.fee)
    console.log(body)
    love.set(body)



    love.save().then(function (love) {

        cache.delete(`bpwall:love:${req.session.bpwall_id}`)




        let promise = Parse.Promise.as();
        if (options.action == "add") {

            var Bpwall = Parse.Object.extend({className: "bpwall"});

            var bpwall = new Bpwall();
            bpwall.id = req.session.bpwall_id

            promise = bpwall.fetch().then(function (wall) {

                let relation = bpwall.relation("love")
                relation.add(love)
                bpwall.save()
            })
        }
        return promise

    }).then(function () {
        cache.exec({bpwall_id:req.session.bpwall_id,name:'love'})
       

        res.json(ret)

    }, function (err) {
        "use strict";

        console.log(err)
        ret.error = 1;
        ret.message = err
        res.json(ret)
    })


};