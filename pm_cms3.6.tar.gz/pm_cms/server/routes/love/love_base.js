const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});

const moment = require("moment")

module.exports = function (config, req, res) {

    const ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    // let account_uid = req.session.account_uid
    let id = req.params.id
    let options = {}

    var query = new Parse.Query("bpwall");
    query.equalTo("objectId",req.session.bpwall_id);

    query.first().then(function (bpwall) {
        options.admin_el_times=bpwall.get("admin_el_times")
        options.times=[0,1,2,3,4,5]
        var promise = new Parse.Promise();

        config.view.render('wall/love_base.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            }else{
                ret.content = html
                promise.resolve(html + "");
            }


        })
        return promise;

    }).then(function (html) {


        res.json(ret);

    }, function (err) {

        let ret = {
            err: err
        }
        res.json(ret)
    })

};

