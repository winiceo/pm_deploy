let config = require("../config");
const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "保存成功"}
    //let account_uid= req.session.account_uid
    let options = {
        action: "edit"
    }

    //res.json(body)
    var query = new Parse.Query("love_item");
    query.equalTo("objectId", body.id);

    let LoveItem = Parse.Object.extend("love_item");
    let loveItem = new LoveItem();
    if (body.id) {

        loveItem.id = body.id
    }else{
        options.action="add"
        delete(body.id)
    }
    //body.sort=parseInt(body.sort)
    body.duration=parseFloat(body.duration)
    body.fee=parseFloat(body.fee)
    console.log(body)
    loveItem.set(body)



    loveItem.save().then(function (item) {


        "use strict";


        let promise = Parse.Promise.as();
        if (options.action == "add") {

            var Bpwall = Parse.Object.extend({className: "bpwall"});

            var bpwall = new Bpwall();
            bpwall.id = req.session.bpwall_id

            promise = bpwall.fetch().then(function (wall) {

                let relation = bpwall.relation("love_item")
                relation.add(loveItem)
                bpwall.save()
            })
        }
        return promise

    }).then(function () {
        cache.exec({bpwall_id:req.session.bpwall_id,name:'love_item'})

        res.json(ret)

    }, function (err) {
        "use strict";

        console.log(err)
        ret.error = 1;
        ret.message = err
        res.json(ret)
    })


};