
const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
  autoescape: true,
  noCache:true,
  watch:true, });

const moment=require("moment")

module.exports = function(config, req, res) {

  let ret={
    "title": "文件管理",
    "content": "",
    "path": "\/public\/upload\/images\/9496",
    "file_list": [
      {
        "ext": "png",
        "link": "http:\/\/91youyu.oss-cn-shenzhen.aliyuncs.com\/platform\/images\/9496\/148661848184284886.png"
      },
      {
        "ext": "jpg",
        "link": "http:\/\/91youyu.oss-cn-shenzhen.aliyuncs.com\/platform\/images\/9496\/148661849912264326.jpg"
      },
      {
        "ext": "jpg",
        "link": "http:\/\/91youyu.oss-cn-shenzhen.aliyuncs.com\/platform\/images\/9496\/148661851034621023.jpg"
      },
      {
        "ext": "jpg",
        "link": "http:\/\/91youyu.oss-cn-shenzhen.aliyuncs.com\/platform\/images\/9496\/148678353066282705.jpg"
      }
    ]
  }

  let account_uid= req.session.account_uid


  var settingQuery = new Parse.Query("setting");
  let bpwallQuery = new Parse.Query("bpwall");

  bpwallQuery.equalTo("account_uid", account_uid);

  let setting_info={}

  settingQuery.first().then(function (setting) {
    setting_info=setting.toJSON();
    ret.title=setting_info.app_name
    return bpwallQuery.first()

  }).then(function (bpwall) {

    bpwall_info=bpwall.toJSON();

    bpwall_info.startAt=moment(bpwall_info.startAt).format("YYYY-MM-DD HH:mm");

    var html=config.view.render('temp/bpwall.html', { setting:setting_info,bpwall:bpwall_info});

    ret.content=html;
    res.json(ret);

  })

};

