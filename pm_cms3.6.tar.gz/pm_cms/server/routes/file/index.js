module.exports = {
  init: function(app, middleware, config) {
    // Home page for the application
    app.all("/file/ossIndex",

        require("./oss_index").bind(app, config));
  }
};
