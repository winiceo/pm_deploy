const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});
const _=require("lodash")
const moment = require("moment")

module.exports = function (config, req, res) {


    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    let account_uid = req.session.account_uid
    var query = new Parse.Query("account");
    query.equalTo("objectId", account_uid);
    query.include("bpwall")
    let options={}
    options.bpwall_id=req.session.bpwall_id
    query.first().then(function (account) {

        options.account = account
        var promise = new Parse.Promise();
        ret.options = options

        options.loginInfo={
                id: "login_container",
                appid: config.wechat.appid,
                scope: "snsapi_login",
                redirect_uri: config.baseUrl+"/profile/bind",
                state: "1",
                style: "black",
                href: ""
        }

        config.view.render('web/profile.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            } else {
                ret.content = html;
                promise.resolve(html);
            }


        })
        return promise;
    }).then(function () {


        res.json(ret);

    }, function (err) {
        "use strict";
        ret.err = err
        res.json(ret)
    })


};

