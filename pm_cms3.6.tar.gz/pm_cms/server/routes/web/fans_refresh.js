const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});

const moment = require("moment")

module.exports = function (config, req, res) {


    let ret = {"error":0,"message":"粉丝信息更新成功"}
    res.json(ret)

    // let account_uid = req.session.account_uid
    // let bpwall_id = req.session.bpwall_id
    // let options = {}
    //
    //
    // let Bpwall = Parse.Object.extend("bpwall");
    // let bpwall = new Bpwall();
    // bpwall.id =bpwall_id
    // options.bpwall_id=bpwall_id
    // let userQuery=bpwall.relation("wechat_user")
    //
    // userQuery.query().find().then(function (users) {
    //
    //     options.users = users
    //     var promise = new Parse.Promise();
    //     ret.options = options
    //
    //     config.view.render('web/fans.html', options, function (err, html) {
    //         "use strict";
    //
    //         if (err) {
    //             promise.reject(err);
    //         } else {
    //             ret.content = html;
    //             promise.resolve(html);
    //         }
    //
    //
    //     })
    //     return promise;
    // }).then(function () {
    //
    //
    //     res.json(ret);
    //
    // }, function (err) {
    //     "use strict";
    //     ret.err = err
    //     res.json(ret)
    // })


};

