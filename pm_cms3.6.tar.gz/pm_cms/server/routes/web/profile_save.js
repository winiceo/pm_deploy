const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});
const _=require("lodash")
const moment = require("moment")

module.exports = function (config, req, res) {


    let  body=req.body

    let account_uid = req.session.account_uid
    var query = new Parse.Query("account");
    query.equalTo("objectId", account_uid);
    let options={}
    let ret={"error":0,"message":""}
    query.first().then(function (account) {

        if(body.password){
            ret.message="密码修改成功，下次登录请使用新密码"
            account.set("password",body.password)
        }
        if(body.target){
            ret.message=`${body.title}修改成功`

            account.set(body.name,body.value)
        }
        return account.save()


    }).then(function () {


        res.json(ret);

    }, function (err) {
        "use strict";
        ret.err = err
        res.json(ret)
    })


};

