module.exports = {
    init: function (app, middleware, config) {
        // Home page for the application
        app.get("/",
            middleware.clearRedirects,
            middleware.setUserIfTokenExists,
            require("./homepage").bind(app, config));

        app.get("/fans",
            middleware.clearRedirects,
            middleware.setUserIfTokenExists,
            require("./fans").bind(app, config));

        app.all("/fans/keyword/:key",
            require("./fans").bind(app, config));

        app.all("/fans/refresh",

            require("./fans_refresh").bind(app, config));

        app.all("/fans/editMember",

            require("./fans_save").bind(app, config));

        app.all("/fans/joinBlack",

            require("./fans_join_black").bind(app, config));


        app.all("/profile",

            require("./profile").bind(app, config));


        app.all("/profile/password",

            require("./profile_passwrod").bind(app, config));


        app.all("/profile/save",

            require("./profile_save").bind(app, config));





    }
};
