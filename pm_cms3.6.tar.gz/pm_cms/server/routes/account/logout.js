module.exports = function(config, req, res) {

  req.session.account_uid=null;
  req.session.bpwall_id=null;
  res.redirect('/account/login')

};
