module.exports = {
  init: function(app, middleware, config) {
    // Tutorial templates
    app.get("/account/login",
      require("./login").bind(app, config));

    app.post("/account/login",
      require("./login_save").bind(app, config));

    app.get("/account/logout",
      require("./logout").bind(app, config));

    app.get("/account/register",
      require("./register").bind(app, config));

    app.post("/account/register",
      require("./register_save").bind(app, config));


    app.post("/account/register/smscode",
      require("./smscode").bind(app, config));


  }
};
