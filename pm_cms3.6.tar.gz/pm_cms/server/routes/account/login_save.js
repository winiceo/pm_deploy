const Parse = require('../../lib/parse');

module.exports = function (config, req, res) {

    let body = req.body


    let Account = Parse.Object.extend("account");

    let ret = {
        error: 0,
        message: ''
    }

    //{"username":"15810042722","password":"123456","agreement":"true","bar_name":"asdfasdf","token":"a53bf09a1ea0aafa2b9e78b4a76f0d77","sms_code":"4234"}
    var query = new Parse.Query("account");
    query.equalTo("username", body.username);
    query.equalTo("password", body.password);
    query.include("bpwall");

    query.first().then(function (account) {

        if (account) {
            req.session.account_uid = account.id
            req.session.bpwall_id = account.get("bpwall").id


            ret.message = "登录成功"
            res.json(ret)

        } else {
            ret.error = 1
            ret.message = "登录失败，请检查手机号或者密码是否正确"
            res.json(ret)
        }

    })

}
