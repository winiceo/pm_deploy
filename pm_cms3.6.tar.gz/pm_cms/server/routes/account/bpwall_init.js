const Parse = require('../../lib/parse');
const moment = require("moment");
const _ = require("lodash");
const shortUrl=require('./short_url')
module.exports = function (config, account) {


    let Bpwall = Parse.Object.extend("bpwall");
    let bpwall = new Bpwall();
    let wall = {
        "redpack_item": {
            "min_money": "3",
            "reverse_time": "10"
        },
        "show_mobile_title": "true",
        "wall_title": "欢迎光临" + account.get("bar_name"),
        "wall_bg": "http://www.91youyu.cn/static/wall/image/wallbg5.png",
        "pic_size": "middle",
        "font_size": "middle",
        "admin_bp_times": 10,
        "bp_video_audit": "false",
        "roll_pic_size": "small",
        "font_color": "white",
        "screen_light": "1",
        "roll_speed": "1.0",
        "show_num": "20",
        "bp_audit": "false",
        "bp_video": "true",
        "pron_words": [],
        "bp_pic_effect": "close",
        "redpack_effect": "open",
        "wall_qrcode_type": "system",
        "wall_qrcode": "",
        "startAt": moment().unix()
    }
     bpwall.set(wall)


    let settingQuery = new Parse.Query("setting");

    let promise=bpwall.save().then(function(){
        "use strict";

        return  settingQuery.first()
      }).then(function (setting) {

        bpwall.set("bp_item",setting.get("bp_item"))
        bpwall.set("admin_el_times",setting.get("admin_el_times"))
        bpwall.set("admin_ds_times",setting.get("admin_ds_times"))
        let promises = [];
        let fileds = [ "love", "love_item", "guest", "present"]

        _.each(fileds, function (n) {
            let parseObject = Parse.Object.extend(n);
            let relation = bpwall.relation(n);
            let objects = []
            _.each(setting.get(n), function (item) {
                "use strict";

                let object = new parseObject();
                object.set(item)
                object.set("bpwall",bpwall)
                objects.push(object)
            })

            let p = Parse.Object.saveAll(objects)
                .then(function (result) {

                    relation.add(result);

                })
            promises.push(p);
        });


        return Parse.Promise.when(promises);


    }).then(function(){
        "use strict";
        return shortUrl(config,bpwall.id)
    }).then(function (short_url) {


        bpwall.set("wechat_qrcode", short_url) //手机端网址
        bpwall.set("mobile_wall_url", config.appURL + "/app/" + bpwall.id) //手机端网址
        bpwall.set("mobile_face_url", config.appURL + "/face/" + bpwall.id) //手机交友
        bpwall.set("web_wall_url", config.appURL + "/screen/" + bpwall.id) //大屏地址


        return bpwall.save()

    }, function (err) {

        console.log(err)
        return Parse.Promise.error(err);
    })

    return promise;


}
