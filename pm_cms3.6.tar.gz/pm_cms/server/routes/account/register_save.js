const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');
let moment = require("moment");


module.exports = function (config, req, res) {

    let body = req.body
    let ret = {
        error: 0,
        message: ''
    }
    req.session.account_uid = null;
    req.session.bpwall_id = null;
    let options = {}

    let query = new Parse.Query("account");
    query.equalTo("username", body.username);
    query.first().then(function (account) {

        if (!account) {
            let Account = Parse.Object.extend("account");

            account = new Account();
            account.set("username", body.username)
            account.set("password", body.password)
            account.set("agreement", body.agreement)
            account.set("bar_name", body.bar_name)
            account.set("money", 0)
            return account.save()
        } else {
            return Parse.Promise.error("此手机号已注册");

        }


    }).then(function (account) {
        options.account = account
        cache.exec({
            name: 'create_bpwall',
            account_id: account.id
        })
        req.session.account_uid = account.id
        ret.message = "注册成功"
        res.json(ret)

        if (account.get('bpwall')) {
            req.session.bpwall_id = account.get('bpwall').id

        } else {
            regetBpwall(account)
        }

        //return bpwall_int(config,account)

    }, function (error) {
        console.log(error)
        ret.error = 1;
        ret.message = error
        res.json(ret)
    }).then(function () {
        "use strict";

    })


}

// ).then(function (bpwall) {
//
//     options.account.set("bpwall",bpwall)
//
//     req.session.uniacid = bpwall.id
//     req.session.bpwall_id = bpwall.id
//
//     return options.account.save();
//
// }).then(function () {
//
//     res.json(ret)