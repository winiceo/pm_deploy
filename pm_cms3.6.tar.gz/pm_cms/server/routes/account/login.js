
module.exports = function(config, req, res) {
  let options={
    wechat_appid:config.wechat.appid,
    callback_url:''
  }
  res.render("account/login.html",{config:options});
};
