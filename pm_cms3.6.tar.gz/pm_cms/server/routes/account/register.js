module.exports = function(config, req, res) {
  res.render("account/register.html");
};
