const Parse = require('../../lib/parse');
let randomstring = require("randomstring");

module.exports = function (config, req, res) {

    let body = req.body
    let code = randomstring.generate({
        length: 6,
        charset: 'numeric'
    });


    let Smscode = Parse.Object.extend("smscode");
    let smscode = new Smscode();
    smscode.set("mobile", body.mobile)
    smscode.set("code", code)

    let ret = {
        error: 0,
        message: ''
    }
    smscode.save().then(
        function (smscode) {
            ret.code = code
            ret.token=code
            res.json(ret)
        },
        function (error) {
            ret.error = 1
            ret.message = "获取验证码失败"
            res.json(ret)
        });


}
