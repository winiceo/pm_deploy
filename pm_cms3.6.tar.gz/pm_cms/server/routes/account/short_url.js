/**
 * Created by leven on 17/2/18.
 */
const WechatAPI = require('wechat-api')
const Parse = require('../../lib/parse');


module.exports = function (config, id) {


    let api = new WechatAPI(config.wechat.appid, config.wechat.appsecret);
    var promise = new Parse.Promise();







    api.createLimitQRCode(id, function (err, result) {
        "use strict";
        console.log(err)
        if(err){
            promise.reject(err)
        }
        promise.resolve(result.url);
        // var url = api.showQRCodeURL(result.ticket);
        // console.log(url)

        // api.shorturl('url', function (err, surl) {
        //     if(err){
        //         promise.reject(err)
        //     }
        //     promise.resolve(surl.short_url);
        // });

    });

    return promise;

}