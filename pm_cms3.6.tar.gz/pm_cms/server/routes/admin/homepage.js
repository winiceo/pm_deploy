
const Parse = require('../../lib/parse');

module.exports = function(config, req, res) {
  let account_uid= req.session.account_uid
  if(!account_uid){
    res.redirect("/account/login")
  }

  var accountQuery = new Parse.Query("account");

  accountQuery.equalTo("objectId", account_uid);

  let bpwall_info={}
  let account_info={}

  accountQuery.first().then(function (account) {
    account_info=account.toJSON();
    req.session.account_uid=account.id
    if (account.get('bpwall')) {
      req.session.bpwall_id = account.get('bpwall').id
    }
    if(req.session.bpwall_id){
      res.render("admin/index.html", {account:account_info});
    }else{
      res.render("admin/loading.html", {account:account_info});
    }

  }).then(function () {

  })

};
