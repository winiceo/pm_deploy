const proxy1 = require('express-http-proxy');
const proxy = require('http-proxy-middleware');
var url = require('url');

const proxy_http = "http://localhost:7001"
module.exports = {
    init: function (app, middleware, config) {
        // Home page for the application
        app.get("/admin",
            middleware.clearRedirects,
            middleware.setUserIfTokenExists,
            require("./homepage").bind(app, config));

        app.all('/admin/main',require("./main").bind(app, config));

        // app.use('/oss/list', proxy('localhost:7001/oss/list', {
        //   forwardPath: function(req, res) {
        //     console.log(require('url').parse(req.url).path)
        //     return require('url').parse(req.url).path;
        //   }
        // }));
        //app.use('/api/p', proxy({target: proxy_http, changeOrigin: true}));


        // var options = {
        //   target: 'http://localhost:7001', // target host
        //   changeOrigin: true,               // needed for virtual hosted sites
        //   ws: true,                         // proxy websockets
        //   // pathRewrite: {
        //   //   '^/api/old-path' : '/api/new-path',     // rewrite path
        //   //   '^/api/remove/path' : '/path'           // remove base path
        //   // },
        //   router: {
        //     // when request.headers.host == 'dev.localhost:3000',
        //     // override target 'http://www.example.org' to 'http://localhost:8000'
        //     //'localhost:3000' : 'http://localhost:8000'
        //   }
        // };

// create the proxy (without context)
//     var exampleProxy = proxy(options);
//      app.use('/api/p', proxy(url.parse('http://localhost:7001/api/p')));
//     app.use('/api/p/*', proxy1('localhost:7001', {
//       forwardPath: function(req, res) {
//         console.log(req.body)
//         return req.originalUrl;
//       },
//       reqAsBuffer: true,
//       reqBodyEncoding: null
//     }));
        // app.get('/api/p/*', proxy({
        //   // cache: 1,
        //   // cacheMaxAge: 60,
        //   url: "http://localhost:7001/api/p/*",
        //   // query: {
        //   //   secret_key: "asdfasd"
        //   // },
        //   // headers: {
        //   //   'X-Custom-Header': "asdfasdf"
        //   // }
        // }));
        //app.use('/oss/list', proxy('localhost:7001/oss/list'));

        var proxy_filter = function (path, req) {
            return path.match('^/api/p') && ( req.method === 'GET' || req.method === 'POST' );
        };

        var proxy_options = {
            target: 'http://localhost:7001',
            logLevel: 'debug',
            //logProvider:
            onError(err, req, res) {
                res.writeHead(500, {
                    'Content-Type': 'text/plain'
                });
                res.end('Something went wrong. And we are reporting a custom error message.' + err);
            },
            onProxyRes(proxyRes, req, res) {
                //proxyRes.headers['x-added'] = 'foobar';     // add new header to response
                //delete proxyRes.headers['x-removed'];       // remove header from response
            },
            onProxyReq(proxyReq, req, res) {

                if (req.body) {
                    let bodyData = JSON.stringify(req.body);
                    // incase if content-type is application/x-www-form-urlencoded -> we need to change to application/json
                    proxyReq.setHeader('Content-Type','application/json');
                    proxyReq.setHeader('Content-Length', Buffer.byteLength(bodyData));
                    // stream the content
                    proxyReq.write(bodyData);
                }
                // if (req.method == "POST" && req.body) {
                //     console.log(req.body)
                //     console.log(encodeURIComponent(JSON.stringify(req.body)))
                //
                //     proxyReq.write(encodeURIComponent(JSON.stringify(req.body)));
                //     proxyReq.end();
                // }
            }
        };

// Proxy configuration
        var proxy = require('http-proxy-middleware')(proxy_filter, proxy_options);


        app.all('/api/p/*', function (req, res, next) {

            //req.body.jdbc_sas = 'jdbc:postgresql://pg_dev:5432/sasdb';
            //req.body.jdbc_agency = 'jdbc:postgresql://pg_dev:5432/agency0329';
            //console.log('proxy body:',req.body);

            proxy(req, res, next);
        });

    }
};
