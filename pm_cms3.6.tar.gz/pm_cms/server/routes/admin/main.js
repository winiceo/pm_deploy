
const Parse = require('../../lib/parse');

module.exports = function(config, req, res) {
  let account_uid= req.session.account_uid
  if(!account_uid){
    res.redirects("/account/login")
  }

  var accountQuery = new Parse.Query("account");

  accountQuery.equalTo("objectId", account_uid);
  accountQuery.include("bpwall")
  let bpwall_info={}
  let account_info={}

  accountQuery.first().then(function (account) {
    account_info=account.toJSON();

    bpwall_info=account.get("bpwall").toJSON();
    console.log(bpwall_info)
    console.log(account_info)
    res.render("admin/main.html", {bpwall:bpwall_info,account:account_info});

  })

};
