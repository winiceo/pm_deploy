/**
 * Created by leven on 17/2/10.
 */



let env = require("../../lib/environment");

let co = require('co');
let oss = require('ali-oss');
let moment = require("moment");



module.exports = function (config, req, res) {



    var store = oss({
        region: env.get("ALI_OSS_REGION"),
        accessKeyId: env.get("ALI_OSS_ID"),
        accessKeySecret: env.get("ALI_OSS_SECRET"),
        bucket:'bpwall/'+req.session.bpwall_id,

    });
    var result =  store.list();
    console.log(result.objects);
    res.json(result)





};


