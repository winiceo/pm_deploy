module.exports = {
    init: function (app, middleware, config) {

        app.all('/finance',
            require("./finance").bind(app, config));
        app.all('/finance/withdraw',
            require("./finance_withdraw").bind(app, config));

        app.all('/finance/account',
            require("./finance_account").bind(app, config));

        app.all('/finance/account/add',
            require("./finance_account_edit").bind(app, config));
        app.all('/finance/account/edit/:id',
            require("./finance_account_edit").bind(app, config));

        app.all('/finance/account/save',
            require("./finance_account_save").bind(app, config));
    }
};
