const Parse = require('../../lib/parse');
 
const _ = require("lodash")
const moment = require("moment")

module.exports = function (config, req, res) {

    const types = [
        {
            name: "霸屏收入",
            type: 1,
            to:"平台余额",
            act:0
        }, {
            name: "收入分成",
            type: 2,
            to:"平台",
            act:1
        }, {
            name: "微信分成",
            type: 3,
            to:"腾讯公司",
            act:1
        }, {
            name: "提现",
            type: 4,
            to:'银行转账',
            act:1
        }
    ]
    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    let account_uid = req.session.account_uid
    let bpwall_id = req.session.bpwall_id
    let keywords = req.params.key

    let page = req.query.page
    let options = {
        pagesize: 10,
        page: parseInt(page) || 1,
        keywords: keywords
    }


    let Bpwall = Parse.Object.extend("bpwall");
    let bpwall = new Bpwall();
    bpwall.id = bpwall_id
    options.bpwall_id = bpwall_id
    let financeQuery = bpwall.relation("finance").query()
     

    financeQuery.count().then(function (count) {
        options.count = count
        options.pages = Math.ceil(count / options.pagesize)
        financeQuery.limit(options.pagesize)
        financeQuery.skip(options.pagesize * (options.page - 1))


        return financeQuery.find()
    }).then(function (finances) {

        const type=["+","-"]
        finances.map(function (finance) {
            finance.set("time",formatDate(finance.createdAt))
            //finance.set("money_show",type[finance.get('act')]+finance.get("money"))
        })
        options.finances = finances
        var promise = new Parse.Promise();
        ret.options = options

        config.view.render('finance/index.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            } else {
                ret.content = html;
                promise.resolve(html);
            }


        })
        return promise;
    }).then(function () {


        res.json(ret);

    }, function (err) {
        "use strict";
        ret.err = err
        res.json(ret)
    })


};
function formatDate (data,format) {
   return  moment(data, moment.ISO_8601).format('YYYY/MM/DD HH:mm');
}


