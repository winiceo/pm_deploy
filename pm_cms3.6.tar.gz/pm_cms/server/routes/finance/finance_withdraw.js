/**
 * Created by leven on 17/2/19.
 */

const Parse = require('../../lib/parse');

const _=require("lodash")
const moment = require("moment")

module.exports = function (config, req, res) {


    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }
    let options={}

    let account_uid = req.session.account_uid
    let accountQuery = new Parse.Query("account");

    accountQuery.equalTo("objectId", account_uid);
    accountQuery.include("finance_account")
    accountQuery.first().then( function(account){

        var promise = new Parse.Promise();
        ret.options = options
        options.account=account;

        config.view.render('finance/withdraw.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            } else {
                ret.content = html;
                promise.resolve(html);
            }


        })
        return promise;
    }).then(function () {


        res.json(ret);

    }, function (err) {
        "use strict";
        ret.err = err
        res.json(ret)
    })


};

