/**
 * Created by leven on 17/2/19.
 */

const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});
const _=require("lodash")
const moment = require("moment")

module.exports = function (config, req, res) {


    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }

     let account_uid = req.session.account_uid
    console.log(req.session)
    let options = {}
    let Account = Parse.Object.extend("account");
    let account = new Account();
    account.id =account_uid

    console.log(account)

    let Query=account.relation("finance_account")

    Query.query().first().then(function (account) {
        console.log(account)

        options.account = account

        var promise = new Parse.Promise();
        ret.options = options

        config.view.render('setting/finance_account.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            } else {
                ret.content = html;
                promise.resolve(html);
            }


        })
        return promise;
    }).then(function () {


        res.json(ret);

    }, function (err) {
        "use strict";
        ret.err = err
        res.json(ret)
    })


};

