let config = require("../config");
const Parse = require('../../lib/parse');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "操作成功"}
    //let account_uid= req.session.account_uid
    let options = {
        action: "edit"
    }

    //res.json(body)
    var query = new Parse.Query("finance_account");
    query.equalTo("objectId", body.id);

    let FinanceAccount = Parse.Object.extend("finance_account");
    let finance_account = new FinanceAccount();
    if (body.id) {

        finance_account.id = body.id
    } else {
        options.action = "add"
        delete(body.id)
    }
    console.log(body)
    finance_account.set(body)


    finance_account.save().then(function (gg) {

        console.log(gg.toJSON())
        "use strict";


        let promise = Parse.Promise.as();
        if (options.action == "add") {

            var Account = Parse.Object.extend({className: "account"});

            var account = new Account();
            account.id = req.session.account_uid

            promise = account.fetch().then(function (account) {

                let relation = account.relation("finance_account")
                relation.add(finance_account)
                account.save()
            })
        }
        return promise

    }).then(function () {

        res.json(ret)

    }, function (err) {
        "use strict";

        console.log(err)
        ret.error = 1;
        ret.message = err
        res.json(ret)
    })


};