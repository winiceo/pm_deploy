const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});

const moment = require("moment")

module.exports = function (config, req, res) {

    const ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    // let account_uid = req.session.account_uid
    let id = req.params.id
    let options = {}
    let query = new Parse.Query("present");


    query.equalTo("objectId", id);
   // query.include("wechatuser")


    query.first().then(function (present) {
        if(!present){
            present = Parse.Object.extend("present").createWithoutData()

        }
        options.present = present
        options.bpwall_id = id
        options.guest_type = ["嘉宾", '服务员', '观众']
        var promise = new Parse.Promise();

        config.view.render('wall/reward_edit.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            }

            ret.content = html
            promise.resolve(html + "");
        })
        return promise;

    }).then(function (html) {
        ret.options=options
        res.json(ret);

    }, function (err) {

        let ret = {
            err: err
        }
        res.json(ret)
    })

};

