const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});

const moment = require("moment")

module.exports = function (config, req, res) {


    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    let account_uid = req.session.account_uid
    let options = {}

    let accountQuery = new Parse.Query("account");

    accountQuery.equalTo("objectId", account_uid);
    accountQuery.include("bpwall.guest")
    accountQuery.first().then(function (account) {
        "use strict";
        let relation=account.get("bpwall").get("guest")
        return relation.query().find()
    }).then(function(guests){


        options.guests=guests
        var html = config.view.render('wall/play_reward.html', options);

        ret.content = html;
        ret.options=options

        res.json(ret);

    }, function (err) {
        "use strict";
        res.json(err)
    })



};

