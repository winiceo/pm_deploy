module.exports = {
  init: function(app, middleware, config) {

    app.all('/web/error',  require("./error").bind(app, config));

    app.all('/message',
        require("./message").bind(app, config));
    //wall相关
    app.get('/wall/chats',
        require("./wall_chats").bind(app, config));

    app.post('/wall/chats/editAjax',
        require("./bpwall").bind(app, config));

    app.all('/wall/chats/wallPlugins', function(req,res){
      res.sendfile("./server/routes/api/wall_plugins.json")

    });

    // app.all('/wall/chats/wallRecord',  require("./wall_record").bind(app, config));


    app.all('/wall/play_reward',  require("./play_reward").bind(app, config));
    app.all('/wall/play_reward/setting',  require("./play_reward").bind(app, config));
    app.all('/wall/play_reward/rewarditem',  require("./rewarditem").bind(app, config));
    app.all('/wall/reward/save',  require("./reward_save").bind(app, config));

    app.all('/wall/play_reward/addItem',  require("./reward_edit").bind(app, config));

    app.all('/wall/play_reward/base',  require("./reward_base").bind(app, config));
    app.all('/wall/play_reward/modifySettings',  require("./reward_base_save").bind(app, config));




    app.all('/wall/reward/edit/:id',  require("./reward_edit").bind(app, config));
    app.all('/wall/reward/remove',  require("./reward_remove").bind(app, config));


    app.all('/wall/play_reward/addGuest',  require("./guest_edit").bind(app, config));

    app.all('/wall/guest/edit/:id',  require("./guest_edit").bind(app, config));

    app.all('/wall/guest/save',  require("./guest_save").bind(app, config));
    app.all('/wall/guest/remove',  require("./guest_remove").bind(app, config));

     app.all('/wall/select/fans',  require("./fans_list").bind(app, config));
     app.all('/wall/fans/search/keyword/:key',  require("./fans_list").bind(app, config));


     app.all('/message/act/:act',  require("./message_delete").bind(app, config));


  }
};
