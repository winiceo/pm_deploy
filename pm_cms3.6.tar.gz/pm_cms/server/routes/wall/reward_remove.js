const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});

const moment = require("moment")
const cache = require("../../lib/cache")

module.exports = function (config, req, res) {

    const ret ={"error":0,"message":"项目删除成功"}

    // let account_uid = req.session.account_uid
    let id = req.body.id
    let options = {}
    let query = new Parse.Query("present");


    query.equalTo("objectId", id);
    // query.include("wechatuser")


    query.first().then(function (item) {

         

        return item.destroy()

    }).then(function (html) {
        cache.exec({bpwall_id:req.session.bpwall_id,name:'present'})

        res.json(ret);

    }, function (err) {

        ret.err=err
        res.json(ret)
    })

};

