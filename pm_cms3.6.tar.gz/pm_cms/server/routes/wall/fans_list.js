const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});
const _ = require("lodash")
const moment = require("moment")

module.exports = function (config, req, res) {


    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    let account_uid = req.session.account_uid
    let bpwall_id = req.session.bpwall_id
    let keywords = req.params.key

    let page = req.query.page
    let options = {
        pagesize: 4,
        page: parseInt(page) || 1,
        keywords:keywords
    }


    let Bpwall = Parse.Object.extend("bpwall");
    let bpwall = new Bpwall();
    bpwall.id = bpwall_id
    options.bpwall_id = bpwall_id
    let userQuery = bpwall.relation("wechat_user").query()
    var promise = new Parse.Promise();
    if(keywords){
        userQuery.contains("nickname",keywords)

    }

    userQuery.count().then(function (count) {
        options.count = count
        options.pages = Math.ceil(count / options.pagesize)
        userQuery.limit(options.pagesize)
        userQuery.skip(options.pagesize * (options.page-1))


        return userQuery.find()
    }).then(function (users) {
        //
        let members = {}

        _.each(users, function (n) {
            "use strict";
            members[n.id] = n.toJSON()
        })
        options.members = members
        options.users = users
        var promise = new Parse.Promise();
        ret.options = options

        config.view.render('wall/fans_select.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            } else {
                ret.content = html;
                promise.resolve(html);
            }


        })
        return promise;
    }).then(function () {


        res.json(ret);

    }, function (err) {
        "use strict";
        ret.err = err
        res.json(ret)
    })


};

