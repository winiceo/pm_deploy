let config = require("../config");
const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "操作成功"}
    //let account_uid= req.session.account_uid
    let options = {
        action: "edit"
    }

    //res.json(body)
    var query = new Parse.Query("guest");
    query.equalTo("objectId", body.id);

    let Guest = Parse.Object.extend("guest");
    let guest = new Guest();
    if (body.id) {

        guest.id = body.id
    }else{
        options.action="add"
        delete(body.id)
    }
    body.sort=parseInt(body.sort)
    guest.set(body)

    if (body.uid) {

        let WechatUser = Parse.Object.extend("wechat_user");

        wuser = new WechatUser();
        wuser.id = body.uid
        guest.set('wechatuser', wuser)
    }

    guest.save().then(function (gg) {

        cache.exec({bpwall_id:req.session.bpwall_id,name:'guest'})


        let promise = Parse.Promise.as();
        if (options.action == "add") {

            var Bpwall = Parse.Object.extend({className: "bpwall"});

            var bpwall = new Bpwall();
            bpwall.id = req.session.bpwall_id

            promise = bpwall.fetch().then(function (wall) {

                let relation = bpwall.relation("guest")
                relation.add(guest)
                bpwall.save()
            })
        }
        return promise

    }).then(function () {

        res.json(ret)

    }, function (err) {
        "use strict";

        console.log(err)
        ret.error = 1;
        ret.message = err
        res.json(ret)
    })


};