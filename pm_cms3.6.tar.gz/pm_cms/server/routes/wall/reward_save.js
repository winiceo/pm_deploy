let config = require("../config");
const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "操作成功"}
    //let account_uid= req.session.account_uid
    let options = {
        action: "edit"
    }

    //res.json(body)
    var query = new Parse.Query("present");
    query.equalTo("objectId", body.id);

    let Present = Parse.Object.extend("present");
    let present = new Present();
    if (body.id) {

        present.id = body.id
    }else{
        options.action="add"
        delete(body.id)
    }
    body.sort=parseInt(body.sort)
    body.bp_time=parseFloat(body.bp_time)
    body.price=parseFloat(body.price)
    console.log(body)
    present.set(body)



    present.save().then(function () {

        let promise = Parse.Promise.as();
        if (options.action == "add") {

            var Bpwall = Parse.Object.extend({className: "bpwall"});

            var bpwall = new Bpwall();
            bpwall.id = req.session.bpwall_id

            promise = bpwall.fetch().then(function (wall) {

                let relation = bpwall.relation("present")
                relation.add(present)
                bpwall.save()
            })
        }
        return promise

    }).then(function () {
        cache.exec({bpwall_id:req.session.bpwall_id,name:'present'})

        res.json(ret)

    }, function (err) {
        "use strict";

        console.log(err)
        ret.error = 1;
        ret.message = err
        res.json(ret)
    })


};