const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");
nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});
const _ = require("lodash")
const moment = require("moment")

module.exports = function (config, req, res) {


    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    let account_uid = req.session.account_uid
    let bpwall_id = req.session.bpwall_id
    let keywords = req.params.key

    let page = req.query.page
    let options = {
        pagesize: 4,
        page: parseInt(page) || 1,
        keywords: keywords
    }


    let Bpwall = Parse.Object.extend("bpwall");
    let bpwall = new Bpwall();
    bpwall.id = bpwall_id
    options.bpwall_id = bpwall_id
    let messageQuery = bpwall.relation("message").query()
    messageQuery.equalTo("is_delete", 0);

    messageQuery.count().then(function (count) {
        options.count = count
        options.pages = Math.ceil(count / options.pagesize)
        messageQuery.limit(options.pagesize)
        messageQuery.skip(options.pagesize * (options.page - 1))


        return messageQuery.find()
    }).then(function (messages) {
        let obj = {
            "text": "普通上墙",
            "ds": "打赏",
            "bp": "霸屏",
            "el": "表白",
            "rp": "红包",
        }
        if (messages.length > 0) {
            _.each(messages, function (n, i) {
                "use strict";
                messages[i].set("type_name", obj[n.get("type")])
                //console.log(messages[i].toJSON())
            })

        }
        options.messages = messages
        var promise = new Parse.Promise();
        ret.options = options

        config.view.render('wall/messages.html', options, function (err, html) {
            "use strict";

            if (err) {
                promise.reject(err);
            } else {
                ret.content = html;
                promise.resolve(html);
            }


        })
        return promise;
    }).then(function () {


        res.json(ret);

    }, function (err) {
        "use strict";
        ret.err = err
        res.json(ret)
    })


};

