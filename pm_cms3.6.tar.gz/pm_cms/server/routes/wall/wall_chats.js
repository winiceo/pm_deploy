const Parse = require('../../lib/parse');
const nunjucks = require("nunjucks");

const dateFilter = require('nunjucks-date-filter');

nunjucks.configure('views', {
    autoescape: true,
    noCache: true,
    watch: true,
});
var temp = new nunjucks.Environment(new nunjucks.FileSystemLoader('views'),
    { autoescape: false });

temp.addFilter("date", dateFilter);
const moment = require("moment")

module.exports = function (config, req, res) {

    let ret = {
        "title": "吧里霸乐",
        "content": ""
    }

    let account_uid = req.session.account_uid
    let options = {
        setting: [],

        bgs: []
    }
    for(var i=1;i<=5;i++){
        options.bgs.push(config.ossURL+"/static/wall/image/wallbg"+i+".png")

    }

    let accountQuery = new Parse.Query("account");
    let settingQuery = new Parse.Query("setting");

    accountQuery.equalTo("objectId", account_uid);
    accountQuery.include("bpwall.bp_item")
    settingQuery.first().then(function (setting) {

        if (setting) {
            options.setting = setting.toJSON();
            ret.title = options.setting.app_name
        }


        return accountQuery.first()
    }).then(function(account){
        "use strict";
        options.account=account

    //     let query = new Parse.Query("bp_item");
    //     query.equalTo("bpwall", account.get("bpwall"));
    //     return query.find()
    //
    // }).then(function (bp_items) {

        // options.bp_items=bp_items
        options.bpwall=account.get("bpwall").toJSON();
        options.bpwall.startAt = moment(options.bpwall.startAt).format("YYYY-MM-DD HH:mm");
          var html = temp.render('wall/bpwall.html', options);
        //
        ret.content = html;
        //ret.options=options

        res.json(ret);

    }, function (err) {
        "use strict";
        res.json(err)
    })


};

