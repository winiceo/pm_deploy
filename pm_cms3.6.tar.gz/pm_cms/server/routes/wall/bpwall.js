let config = require("../config");
const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');


module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "修改设置成功"}
    let account_uid = req.session.account_uid


    var query = new Parse.Query("account");

    query.get(account_uid).then(function (account) {
        console.log(account)
        body.admin_bp_times = parseInt(body.admin_bp_times)
        // body.admin_bp_times = parseInt(body.admin_bp_times)
        body.screen_light=parseInt(body.screen_light)
        body.roll_speed=parseFloat(body.roll_speed)
        body.show_num=parseInt(body.show_num)
        console.log(body)
        account.get("bpwall").set(body)

        return account.get("bpwall").save()

    }).then(function () {
        cache.exec({name: 'cache_bpwall', bpwall_id: req.session.bpwall_id})

        res.json(ret)

    }, function (err) {
        "use strict";
        ret.error = 1;
        ret.message = err
        res.json(ret)
    })


};