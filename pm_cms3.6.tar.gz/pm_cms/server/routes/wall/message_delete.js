const Parse = require('../../lib/parse');

const cache = require("../../lib/cache")

module.exports = function (config, req, res) {

    const ret ={"error":0,"message":"操作成功"}

    // let account_uid = req.session.account_uid
    let id = req.body.id
    let act=req.params.act
    let bpwall_id = req.session.bpwall_id




    if(act=="clear"){

        cache.exec({bpwall_id:bpwall_id,name:"admin_delete_message",ids:"all"})

        // let Bpwall = Parse.Object.extend("bpwall");
        // let bpwall = new Bpwall();
        // bpwall.id = bpwall_id
        //
        // let messageQuery = bpwall.relation("message").query()
        // messageQuery.find().then(function (messages) {
        //     messages.map(function (message) {
        //         message.set("is_delete",1)
        //     })
        //     return Parse.Object.saveAll(messages)
        //    // return Parse.Object.destroyAll(messages)
        // }).then(function (messages) {
        //     res.json(ret);
        //
        // },function (e) {
        //     ret.err=e
        //     res.json(ret);
        //
        // })
    }else{
        cache.exec({bpwall_id:bpwall_id,name:"admin_delete_message",ids:[id]})

        //cache.exec({bpwall_id:bpwall_id,name:"admin_delete_message",ids:[id]})
        // let Message = Parse.Object.extend("message");
        // let message = new Message();
        // message.id = id
        // message.set("is_delete",1)
        // message.save().then(function () {
        //     res.json(ret);
        // },function (e) {
        //     ret.err=e
        //     res.json(ret);
        //
        // })


    }
    res.json(ret);

};

