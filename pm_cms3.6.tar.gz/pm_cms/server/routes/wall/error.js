let config = require("../config");
const Parse = require('../../lib/parse');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": body}
    console.log(body)
    res.json(ret)


};