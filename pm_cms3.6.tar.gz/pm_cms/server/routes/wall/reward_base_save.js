let config = require("../config");
const Parse = require('../../lib/parse');
const cache = require('../../lib/cache');

module.exports = function (config, req, res) {
    let body = req.body;
    let ret = {"error": 0, "message": "修改成功"}
    let options = {}
    var query = new Parse.Query("bpwall");
    query.equalTo("objectId",req.session.bpwall_id);

    query.first().then(function (bpwall) {
        bpwall.set("admin_ds_times", body.admin_ds_times)
        return bpwall.save()

    }).then(function (html) {
        cache.exec({bpwall_id:req.session.bpwall_id,name:'bpwall'})

        res.json(ret);

    }, function (err) {

        let ret = {
            err: err
        }
        res.json(ret)
    })


};