module.exports = {
  init: function(app, middleware, config) {




    app.all('/toDo/index/taskList', function(req,res){
      res.sendfile("./server/routes/api/task_list.json")


    });






    app.all('/setting',
        require("./setting").bind(app, config));
















//
    app.all('/modules', function(req,res){


      res.sendfile("./server/routes/api/modules.json")


    });














    app.all('/wall/shake', function(req,res){
      res.sendfile("./server/routes/api/shake.json")


    });

    app.all('/wall/hitplane', function(req,res){
      res.sendfile("./server/routes/api/hitplane.json")


    });

    app.all('/wall/award', function(req,res){
      res.sendfile("./server/routes/api/award.json")


    });



    app.all('/wall/award/awardGoods', function(req,res){
      res.sendfile("./server/routes/api/award_goods.json")


    });

    app.all('/wall/award/users', function(req,res){
      res.sendfile("./server/routes/api/users.json")


    });

    app.all('/wall/vote', function(req,res){
      res.sendfile("./server/routes/api/vote.json")


    });





  }
};
