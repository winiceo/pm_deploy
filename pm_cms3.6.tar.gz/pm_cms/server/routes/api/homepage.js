var querystring = require("querystring");
var nunjucks = require("nunjucks");

var env = require("../../lib/environment");

function urlLocalizer(locale, remixUrl) {
  return nunjucks.renderString(remixUrl, { locale: locale });
}

module.exports = function(config, req, res) {
  var options={};

  res.render("admin/index.html", options);
};
