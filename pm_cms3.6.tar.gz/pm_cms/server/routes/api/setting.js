 
let config = require("../config");
const Parse = require('../../lib/parse');

module.exports =   function(config, req, res) {


  var query = new Parse.Query("setting");

  query.first().then(function(setting) {
    if(!setting){
      let Bpwall = Parse.Object.extend("setting");
       setting = new Bpwall();
    }
    let data={
      app_name:"吧里霸啦",
      web_name:"千岸互动",
      foot_logo:"2017©71an.com 千岸互动"

    }

    setting.set(data)

    return setting.save()

  }).then(function(message) {

    res.json(message.toJSON())

  })


};