"use strict";

let Nunjucks = require("nunjucks");
let stylus = require('stylus');
let nib = require('nib');
let env = require("./lib/environment");
const moment = require('moment');
moment.locale('zh-cn');

module.exports = function templatize(server, paths) {
    let engine = new Nunjucks.Environment(paths.map(path => new Nunjucks.FileSystemLoader(path)), {
        autoescape: true,
        cache: false,
        noCache:true,
        watch:true,
        throwOnUndefined:false
    });

    engine.addFilter("instantiate", function (input) {
        return (new Nunjucks.Template(input)).render(this.getVariables());
    });
    engine.addFilter("date", function (data,format) {
        let date = moment.unix(date);
        format = format || 'MM-DD HH:mm';
        return date.format(format);
    });

    engine.addFilter("formatmoney", function(money, type) {
        'use strict';

        if (type == 1) {
            return `￥ ${parseFloat(money / 100).toFixed(2)}`;
        } else if (type == 2) {
            return `￥ ${parseFloat(money).toFixed(2)}`;
        } else if (type == 3) {
            return `${parseFloat(money / 100).toFixed(2)}`;
        }else{
            return `￥ ${parseFloat(money / 100).toFixed(2)}`;
        }

    })



    server.view=engine


    engine.express(server);

    server.use(stylus.middleware({

        src: env.get("RESOURCES"),
        dest: env.get("CSS"),
        compile: compile,
        debug: true,
        force: true,
    }));
};


function compile(str, path) {
    return stylus(str)
        .set('filename', path)
        .set('compress', true)
        .use(nib());
}
