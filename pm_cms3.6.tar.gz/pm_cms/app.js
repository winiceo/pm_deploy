'use strict';

const throng = require('throng');
const pmker = require('./server');
const workers = process.env.WEB_CONCURRENCY || 1;

const start = function() {

  const server = pmker.listen(process.env.WEB_PORT, function() {
    console.log("Express server listening on " + process.env.WEB_HOST+":"+process.env.WEB_PORT);
  });

  // const shutdown = function() {
  //   server.close(function() {
  //     process.exit(0);
  //   });
  // };
  //
  // process.on('SIGINT', shutdown);
  // process.on('SIGTERM', shutdown);
};
start()
//throng(workers, start);
