$(function() {
    // 读取body data-type 判断是哪个页面然后执行相应页面方法，方法在下面。
    if(typeof(dataType) === 'undefined'){dataType = $('body').attr('data-type');}
    if(typeof(dataType) != 'undefined'){
        console.log(dataType);
        for (key in pageData) {
            if (key == dataType) {
                pageData[key]();
            }
        }
    }
    autoLeftNav();
    $(window).resize(function() {
        autoLeftNav();
        // console.log($(window).width())
    });
});


// 页面数据
var pageData = {
};

// 风格切换

$('.tpl-skiner-toggle').on('click', function() {
    $('.tpl-skiner').toggleClass('active');
});

$('.tpl-skiner-content-bar').find('span').on('click', function() {
    $('body').attr('class', $(this).attr('data-color'))
    saveSelectColor.Color = $(this).attr('data-color');
    // 保存选择项
    storageSave(saveSelectColor);

});




// 侧边菜单开关


function autoLeftNav() {
    $('.tpl-header-switch-button').on('click', function() {
        if ($('.left-sidebar').is('.active')) {
            if ($(window).width() > 1024) {
                $('.tpl-content-wrapper').removeClass('active');
            }
            $('.left-sidebar').removeClass('active');
        } else {

            $('.left-sidebar').addClass('active');
            if ($(window).width() > 1024) {
                $('.tpl-content-wrapper').addClass('active');
            }
        }
    });

    if ($(window).width() < 1024) {
        $('.left-sidebar').addClass('active');
    } else {
        $('.left-sidebar').removeClass('active');
    }
}


// 侧边菜单
$('.sidebar-nav-sub-title').on('click', function() {
    $(this).siblings('.sidebar-nav-sub').slideToggle(80)
        .end()
        .find('.sidebar-nav-sub-ico').toggleClass('sidebar-nav-sub-ico-rotate');
});

/**
 * 单个粉丝选择
 * @param options
 */
function single_fans_selector(options) {
    options = options || {};
    var avatar_id = options.avatarID || 'avatar'; //头像ID
    var nickname_id = options.nicknameID || 'nickname'; //昵称ID
    var uid_id = options.uidID || 'uid'; //uid赋值ID
    var openid_id = options.openidID || 'openid'; //openid赋值ID
    var wrapper_ele = options.wrapperQuery; //显示头像、昵称的父级元素选择器

    $.ajax({
        type:'post',
        dataType: 'json',
        data: {
            avatar_id: avatar_id,
            nickname_id: nickname_id,
            uid_id: uid_id,
            openid_id: openid_id,
            wrapper_ele: wrapper_ele
        },
        url: '/wall/select/fans',
        success: function (response) {
            var content = response.content;

            popup = AMUI.dialog.popup({
                title: '请选择粉丝',
                content: content
            });
        }
    });
}

/**
 * 多个粉丝选择
 * @param options
 */
function multi_fans_selector(options) {
    options = options || {};
    var uid_name = options.uidName || 'uid'; //uid的input name
    var openid_name = options.openidName || 'openid'; //openid的input name
    var as_attribute = options.asAttribute || false;//作为input属性赋值
    var wrapper_ele = options.wrapperQuery; //显示头像、昵称的父级元素选择器
    var openids = options.openids || [];//初始值

    $.ajax({
        type:'post',
        dataType: 'json',
        data: {
            uid_name: uid_name,
            openid_name: openid_name,
            wrapper_ele: wrapper_ele,
            as_attribute: as_attribute,
            mode: 'multi',
            openids: openids
        },
        url: '/fans/fans',
        success: function (response) {
            var content = response.content;

            popup = AMUI.dialog.popup({
                title: '请选择粉丝',
                content: content,
                onClose: function () {
                    if(selected_member != undefined) {
                        delete selected_member;
                    }
                }
            });
        }
    });
}

var file_item_select_callback = null;
var file_manager_dialog = null;

function file_manager(path, callback) {

    path = path || '';
    console.info(path);
    file_item_select_callback = callback || null;

    $.ajax({
        type:'post',
        dataType: 'json',
        data: {
            path: path,
            page: 1
        },
        url: '/api/p/oss/list',
        success: function (response) {
            file_manager_dialog = AMUI.dialog.popup({
                title: response.title,
                content: response.content
            });

            register_file_select_callback(file_item_select_callback);
        }
    });
}

function close_file_manager() {
    if(file_manager_dialog != null) {
        file_manager_dialog.modal('close');
    }
}

function dir_ajax_load(path, page) {
    path = path || '';

    $.ajax({
        type:'post',
        dataType: 'json',
        data: {
            path: path,
            page: 1
        },
        url: '/fileManager',
        success: function (response) {
            file_manager_dialog = AMUI.dialog.popup({
                title: response.title,
                content: response.content
            });

            register_file_select_callback(file_item_select_callback);
        }
    });
}

function register_file_select_callback(callback, node) {
    if(node == undefined) {
        $('.tpl-file-selector').click(function (e) {
            e.preventDefault();
            var url = $(this).attr('href');
            callback.call(this, url);
        });
    } else {
        node.click(function (e) {
            e.preventDefault();
            var url = $(this).attr('href');
            callback.call(this, url);
        });
    }
}

function remove_selected_fans(obj) {
    $(obj).parent().remove();
}

/**
 * 单个酒吧选择
 * @param options
 */
function uni_account_selector(options) {
    options = options || {};
    var name_id = options.nameID || 'uni_name'; //昵称ID
    var uniacid_id = options.uniacidID || 'uniacid'; //uid赋值ID
    var wrapper_ele = options.wrapperQuery; //显示头像、昵称的父级元素选择器

    $.ajax({
        type:'post',
        dataType: 'json',
        data: {
            name_id: name_id,
            uniacid_id: uniacid_id,
            wrapper_ele: wrapper_ele
        },
        url: '/administrator/uni_account_selector',
        success: function (response) {
            var content = response.content;

            popup = AMUI.dialog.popup({
                title: '请选择酒吧',
                content: content
            });
        }
    });
}

/**
 * 单个酒吧选择
 * @param options
 */
function agent_uni_account_selector(options) {
    options = options || {};
    var name_id = options.nameID || 'uni_name'; //昵称ID
    var uniacid_id = options.uniacidID || 'uniacid'; //uid赋值ID
    var wrapper_ele = options.wrapperQuery; //显示头像、昵称的父级元素选择器

    $.ajax({
        type:'post',
        dataType: 'json',
        data: {
            name_id: name_id,
            uniacid_id: uniacid_id,
            wrapper_ele: wrapper_ele
        },
        url: '/administrator/uni_account_selector/agent',
        success: function (response) {
            var content = response.content;

            popup = AMUI.dialog.popup({
                title: '请选择酒吧',
                content: content
            });
        }
    });
}

/**
 * 多个代理酒吧选择
 * @param options
 */
function multi_agent_sub_bar_selector(options) {
    options = options || {};
    var wrapper_ele = options.wrapperQuery; //显示头像、昵称的父级元素选择器
    var uniacids = options.uniacids || [];//初始值
    var agent_id = options.agent_id || 0;

    $.ajax({
        type:'post',
        dataType: 'json',
        data: {
            wrapper_ele: wrapper_ele,
            uniacids: uniacids,
            agent_id: agent_id
        },
        url: '/administrator/uni_account_selector/agent_sub_bar',
        success: function (response) {
            var content = response.content;

            popup = AMUI.dialog.popup({
                title: '请选择代理酒吧',
                content: content,
                onClose: function () {
                    if(selected_bar != undefined) {
                        delete selected_bar;
                    }
                }
            });
        }
    });
}