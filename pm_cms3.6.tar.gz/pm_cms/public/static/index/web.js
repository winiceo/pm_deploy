/**
 * Created by Administrator on 2016/12/20.
 */
$(function(){
    $(".pub").hover(function(){
        $(this).css({
            "transform":"rotateY(180deg)",
            "transition":"1s"
        });
    },function(){
        $(this).css({
            "transform":"rotateY(0)"
        });
    });
})

$(function(){
    $(".lead").mouseenter(function(){
        var index = $(this).index();
        var w = $(this).width();
        var lineW = $(".bo_line").width();
        var add_ = (w-lineW)/2;
        console.log(w);
        var offseftleft = index*w+add_
        $(".bo_line").css({
            "left":offseftleft,
            "transition":"0.5s cubic-bezier(1,-0.39,.36,2)"
        })
        $(".lead").find(".inner").removeClass("active")
        $(this).find(".inner").addClass("active")
    })
})

$(function(){
    $(".lead").click(function(){
        var index = $(this).index();
        var scroll_top = 0
        switch (index){
            case 0:
                scroll_top=0
                break;
            case 1:
                scroll_top= $(".top").height()+$(".nav").height()+$(".video").height()
                break;
            case 2:
                scroll_top= $(".top").height()+$(".nav").height()+$(".video").height() + $(".main").height()
                break;
            case 3:
                scroll_top= $(document).height()
        }
        console.log(scroll_top)
        $("body").animate({
            scrollTop:scroll_top
        },200)
    })
})


