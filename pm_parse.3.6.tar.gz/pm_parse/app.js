/**
 * Created by leven on 17/1/22.
 */


const env = require("./environment");
const server=require("./index")
server()